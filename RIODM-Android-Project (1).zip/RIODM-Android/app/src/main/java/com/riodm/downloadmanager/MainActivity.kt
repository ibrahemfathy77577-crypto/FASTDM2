package com.riodm.downloadmanager

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection
import java.util.Locale

private val Ink = Color(0xFF101827)
private val Panel = Color(0xFF1B293B)
private val Blue = Color(0xFF39A7FF)
private val Muted = Color(0xFF9AAAC0)
private val Bg = Color(0xFF0B1220)

fun firstLink(s: String?): String? =
    s?.replace(Char(10), ' ')?.split(' ')
        ?.firstOrNull { it.startsWith("http://") || it.startsWith("https://") }

class MainActivity : ComponentActivity() {
    private val incoming = mutableStateOf<String?>(null)
    private var lastClip = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        grab(intent)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Blue, onPrimary = Ink, background = Bg, surface = Panel,
                    onSurface = Color.White, secondary = Color(0xFF65D6C4)
                )
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    RiodmScreen(incoming)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        grab(intent)
    }

    private fun grab(i: Intent?) {
        val u = when (i?.action) {
            Intent.ACTION_VIEW -> i.dataString
            Intent.ACTION_SEND -> firstLink(i.getStringExtra(Intent.EXTRA_TEXT))
            else -> null
        }
        if (u != null) incoming.value = u
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) return
        val cm = getSystemService(ClipboardManager::class.java)
        val clip = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()
        val u = firstLink(clip) ?: return
        if (u != lastClip && incoming.value == null) {
            lastClip = u
            incoming.value = u
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RiodmScreen(incoming: MutableState<String?>) {
    val ctx = LocalContext.current
    val list by Engine.items.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var category by remember { mutableStateOf("الكل") }
    var showSettings by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var url by remember(incoming.value) { mutableStateOf(incoming.value ?: "") }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val active = list.count { it.status == St.RUNNING }
    val downloaded = list.filter { it.status == St.DONE }.sumOf { it.total.coerceAtLeast(0) }
    val shown = list.filter {
        (tab == 0 || (tab == 1 && it.status != St.DONE) || (tab == 2 && it.status == St.DONE)) &&
            (category == "الكل" || Engine.cat(it.name) == category)
    }.sortedByDescending { it.created }

    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("RIODM", fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("ADVANCED DOWNLOAD MANAGER", style = MaterialTheme.typography.labelSmall, color = Muted)
                    }
                },
                actions = {
                    IconButton(onClick = { openVpn(ctx) }) {
                        Icon(Icons.Default.Shield, "VPN", tint = Blue)
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, "الإعدادات", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { url = incoming.value ?: ""; showAdd = true },
                containerColor = Blue, contentColor = Ink,
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("تحميل جديد", fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 100.dp, top = 8.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("مركز التحميل", color = Muted, style = MaterialTheme.typography.labelMedium)
                            Text("$active نشط الآن", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("${list.size} ملف في القائمة", color = Muted)
                        }
                        Surface(color = Blue.copy(alpha = .15f), shape = RoundedCornerShape(18.dp)) {
                            Icon(Icons.Default.Download, null, tint = Blue, modifier = Modifier.padding(16.dp).size(32.dp))
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryTile("إجمالي الملفات", list.size.toString(), Modifier.weight(1f))
                    SummaryTile("مكتمل", list.count { it.status == St.DONE }.toString(), Modifier.weight(1f))
                    SummaryTile("تم تنزيله", fmt(downloaded), Modifier.weight(1f))
                }
            }
            item {
                TabRow(selectedTabIndex = tab, containerColor = Bg, contentColor = Blue) {
                    listOf("الكل", "قيد التحميل", "مكتمل").forEachIndexed { i, label ->
                        Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) })
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("الكل", "فيديو", "صوت", "مستندات", "برامج", "صور", "مضغوطات").forEach { c ->
                        FilterChip(
                            selected = category == c, onClick = { category = c },
                            label = { Text(c) }, colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue.copy(alpha = .2f),
                                selectedLabelColor = Blue
                            )
                        )
                    }
                }
            }
            if (shown.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().padding(vertical = 34.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CloudDownload, null, tint = Muted, modifier = Modifier.size(54.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("لا توجد تحميلات هنا", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("أضف رابط ملف لبدء التحميل", color = Muted)
                    }
                }
            } else {
                items(shown, key = { it.id }) { item -> DownloadCard(item, ctx) }
            }
        }
    }

    if (showAdd || incoming.value != null) {
        AlertDialog(
            onDismissRequest = { showAdd = false; incoming.value = null },
            title = { Text("إضافة تحميل جديد") },
            text = {
                OutlinedTextField(
                    value = url, onValueChange = { url = it },
                    label = { Text("رابط الملف") }, singleLine = false,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    Engine.add(url)
                    showAdd = false
                    incoming.value = null
                }) { Text("ابدأ التحميل") }
            },
            dismissButton = {
                TextButton(onClick = { showAdd = false; incoming.value = null }) { Text("إلغاء") }
            }
        )
    }

    if (showSettings) {
        var segs by remember { mutableFloatStateOf(Engine.maxSegs.toFloat()) }
        var parallel by remember { mutableFloatStateOf(Engine.maxParallel.toFloat()) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("إعدادات RIODM") },
            text = {
                Column {
                    Text("عدد الاتصالات لكل ملف: ${segs.toInt()}")
                    Slider(segs, { segs = it }, valueRange = 1f..64f)
                    Spacer(Modifier.height(8.dp))
                    Text("عدد التحميلات المتزامنة: ${parallel.toInt()}")
                    Slider(parallel, { parallel = it }, valueRange = 1f..5f, steps = 3)
                    Text("إذا رفض الموقع الاتصالات، قلّل العدد.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = { Engine.setPrefs(segs.toInt(), parallel.toInt()); showSettings = false }) { Text("حفظ") }
            }
        )
    }
}

@Composable
private fun SummaryTile(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, color = Muted, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(5.dp))
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
fun DownloadCard(d: DItem, ctx: Context) {
    val pct = if (d.total > 0) (d.done.toFloat() / d.total).coerceIn(0f, 1f) else 0f
    val eta = if (d.speed > 0 && d.total > 0) (d.total - d.done) / d.speed else -1L
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.InsertDriveFile, null, tint = Blue)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(d.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 2)
                    Text(Engine.cat(d.name), color = Muted, style = MaterialTheme.typography.labelSmall)
                }
                Text("${(pct * 100).toInt()}%", color = Blue, fontWeight = FontWeight.Bold)
            }
            LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth(), color = Blue, trackColor = Ink)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${fmt(d.done)} / ${if (d.total > 0) fmt(d.total) else "—"}", color = Muted, style = MaterialTheme.typography.labelSmall)
                Text(
                    when (d.status) {
                        St.RUNNING -> "${fmt(d.speed)}/ث • ${dur(eta)}"
                        St.QUEUED -> "في الانتظار"
                        St.PAUSED -> "متوقف مؤقتاً"
                        St.FAILED -> "فشل: ${d.error ?: "خطأ غير معروف"}"
                        St.DONE -> "اكتمل • Download/RIODM"
                    }, color = if (d.status == St.FAILED) Color(0xFFFF7777) else Muted,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                when (d.status) {
                    St.RUNNING, St.QUEUED -> TextButton(onClick = { Engine.pause(d.id) }) { Icon(Icons.Default.Pause, null); Text("إيقاف") }
                    St.PAUSED, St.FAILED -> TextButton(onClick = { Engine.resume(d.id) }) { Icon(Icons.Default.PlayArrow, null); Text("استكمال") }
                    St.DONE -> TextButton(onClick = { openFile(ctx, d) }) { Icon(Icons.Default.FolderOpen, null); Text("فتح") }
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { Engine.remove(d.id) }) {
                    Icon(Icons.Default.DeleteOutline, null); Text("حذف")
                }
            }
        }
    }
}

fun openVpn(c: Context) {
    val pm = c.packageManager
    val i = listOf("ch.protonvpn.android", "com.wireguard.android")
        .firstNotNullOfOrNull { pm.getLaunchIntentForPackage(it) }
        ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://protonvpn.com/download-android"))
    c.startActivity(i)
}

fun openFile(c: Context, d: DItem) {
    val u = d.uri ?: return
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), Engine.mime(d.name))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { c.startActivity(i) }
}
