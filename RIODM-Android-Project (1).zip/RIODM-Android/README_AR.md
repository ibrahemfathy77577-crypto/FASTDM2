# RIODM – مشروع Android Studio

هذا مشروع أولي منظم لتطبيق مدير تحميلات Android باسم RIODM، مبني على الأكواد التي أرفقتها مع إعادة تصميم الواجهة.

## فتح المشروع
1. فك ضغط الملف.
2. افتح مجلد `RIODM-Android` من Android Studio عبر **Open**.
3. انتظر Gradle Sync مع اتصال بالإنترنت.
4. اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

مسار APK عند نجاح البناء:
`app/build/outputs/apk/debug/app-debug.apk`

## ملاحظات مهمة
- تم تغيير اسم التطبيق والحزمة ومجلد التنزيل إلى RIODM.
- تم الاحتفاظ بمحرك التحميل الأصلي وإعادة تصميم واجهة Compose.
- المشروع يحتاج اختبار بناء وتشغيل فعلي في Android Studio قبل اعتباره إصداراً نهائياً. لم يتم إنشاء APK هنا لعدم توفر Android SDK/Gradle build environment في جلسة إعداد الملفات.
- دعم تقسيم التحميل يعتمد على دعم خادم الملف لطلبات HTTP Range؛ بعض المواقع لا تسمح بذلك.
